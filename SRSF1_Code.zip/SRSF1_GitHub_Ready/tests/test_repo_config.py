"""Check that path configuration works independently of the current directory."""

import importlib.util
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def load_config(environment):
    with patch.dict(os.environ, environment, clear=True):
        spec = importlib.util.spec_from_file_location("test_config", ROOT / "repo_config.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module


class PathConfigurationTests(unittest.TestCase):
    def test_defaults_and_relative_overrides(self):
        defaults = load_config({})
        self.assertEqual(defaults.DATA_DIR, ROOT / "data")
        configured = load_config({"SRSF1_DATA_DIR": "local_inputs"})
        self.assertEqual(configured.DATA_DIR, ROOT / "local_inputs")

    def test_absolute_override_and_output_creation(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve()
            configured = load_config({"SRSF1_DATA_DIR": str(base),
                                      "SRSF1_RESULTS_DIR": str(base / "outputs")})
            self.assertEqual(configured.DATA_DIR, base)
            self.assertFalse(configured.RESULTS_DIR.exists())
            self.assertEqual(configured.prepare_results(), base / "outputs")
            self.assertTrue(configured.RESULTS_DIR.is_dir())

    def test_missing_and_existing_input(self):
        configured = load_config({})
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "matrix.txt"
            with self.assertRaisesRegex(FileNotFoundError, "data/README.md"):
                configured.require_input(path)
            path.write_text("gene\tsample\n", encoding="utf-8")
            self.assertEqual(configured.require_input(path), path)


if __name__ == "__main__":
    unittest.main()
