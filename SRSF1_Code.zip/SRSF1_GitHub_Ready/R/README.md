# R workflows

Run each independent workflow from the repository root. The numerical prefixes
define a reading order; workflows do not depend on outputs from preceding scripts.

```sh
Rscript R/01_survival_entpd1_gse28221.R
Rscript R/02_survival_entpd1_gse70866.R
Rscript R/03_lung_function_entpd1_gse47460.R
Rscript R/04_lung_function_srsf1_gse47460.R
Rscript R/05_lung_function_entpd1_gse32537.R
Rscript R/06_bulk_purine_score_srsf1.R
Rscript R/07_bulk_tgfb_score_adora2b.R
```

`R/_paths.R` reads `SRSF1_DATA_DIR` and `SRSF1_RESULTS_DIR`. Their defaults are
the repository's `data/` and `results/` directories. Set these environment variables
before launching R to use another input or output location. Gene-set metadata belongs
in `resources/gene_sets/`; retrieval instructions are in that directory's README.
Scripts stop with the required file names or fields when inputs are missing.

## Inputs and outputs

Expression matrices contain gene symbols in the first column and numeric sample
columns. The first row contains column names; sample IDs must match the clinical
table. Each workflow writes figures and `session_info.txt` in its own results
directory with the same stem as the script. Bulk workflows also write
`correlation_summary.csv` with the cohort, sample count, available score-gene count,
Spearman rho, and unadjusted p value.

| Workflow | Required inputs under `data/` | Clinical format and required fields | Figure outputs |
| --- | --- | --- | --- |
| 01: ENTPD1 / GSE28221 | `survival/GSE28221/GSE28221_matrix.txt`, `GSE28221_sampleInfo.csv` in the same directory | Expression: tab-separated. Clinical: CSV, first column contains sample IDs; `platform`, numeric `surTime`, numeric `surStatus`. Retains `platform == "Affymetrix"`. | `entpd1_gse28221_survival_4x6.pdf`, `entpd1_gse28221_survival_5.5x5.5.pdf` |
| 02: ENTPD1 / GSE70866_GPL14550 | `survival/GSE70866_GPL14550/GSE70866_GPL14550_matrix.txt`, `GSE70866_GPL14550_sampleInfo.csv` in the same directory | Expression: tab-separated. Clinical: CSV, first column used as row names; `geoID`, numeric `surTime`, numeric `surStatus`. | `entpd1_gse70866_gpl14550_survival_4x6.pdf` |
| 03: ENTPD1 / GSE47460_GPL6480 | `lung_function/GSE47460_GPL6480/GSE47460_GPL6480_matrix.txt`, `GSE47460_GPL6480_sampleInfo.csv` in the same directory | Expression: tab-separated. Clinical: CSV, first column used as row names; `geoID` and the five numeric endpoints below. | `entpd1_gse47460_gpl6480_boxplots.pdf`, `entpd1_gse47460_gpl6480_correlations.pdf/.png` |
| 04: SRSF1 / GSE47460_GPL6480 | Same inputs as workflow 03 | Same fields as workflow 03. | `srsf1_gse47460_gpl6480_boxplots.pdf`, `srsf1_gse47460_gpl6480_correlations.pdf/.png` |
| 05: ENTPD1 / GSE32537 | `lung_function/GSE32537/GSE32537_geneSymbol_mean.csv`, `GSE32537_lung_function.tsv` in the same directory | Expression: CSV. Clinical: tab-separated, first column contains sample IDs; numeric `fvc`, `dlco`, `total_score`. | `entpd1_gse32537_boxplots.pdf`, `entpd1_gse32537_correlations.pdf/.png` |
| 06: SRSF1 / purine metabolism | `bulk_expression/<dataset>/<dataset>_matrix.txt`, recursively collected | Processed tab-separated gene-by-sample matrices with unique gene symbols. One unique dataset directory per input matrix. | `<dataset>_correlation.pdf`, `srsf1_purine_score_correlations.pdf/.png` |
| 07: ADORA2B / TGF-beta signaling | Same matrix layout as workflow 06 | Same processed expression format as workflow 06. | `<dataset>_correlation.pdf`, `adora2b_tgfb_score_correlations.pdf/.png` |

GSE47460 endpoints: `predicted_fev1_pre_bd`, `predicted_fvc_pre_bd`,
`predicted_fev1_post_bd`, `predicted_fvc_post_bd`, and `predicted_dlco`.

Survival status must use the original analysis coding: `0` = censored,
`1` = event. Confirm the underlying follow-up units from the cohort metadata.
Workflow 01 uses `Time (source units)` because the source code did not establish
its unit. Set `time_label` after confirming that definition. Workflow 02 retains
the source `Time (Days)` label.

The original project folder lacks the cleaned expression and clinical inputs used
by workflows 01-05 and the processed bulk cohort inputs used by workflows 06-07.
The downloaded, submitter-normalized GSE32537 series matrix and clinical text extract
do not replace the cleaned gene-symbol matrix and numeric clinical table. Their preprocessing code was not saved
with the source workflows; supply the original cleaned files with the schemas above.

## Methods retained from the source

- Workflow 01 splits the single-gene expression score at the median, with values
  greater than or equal to the median in the High group. It fits Kaplan-Meier curves
  and reports the log-rank p value with a risk table.
- Workflow 02 splits matched samples above or below the mean ENTPD1 expression;
  samples equal to the mean are excluded. The source's two unused range-third
  calculations were excluded from the release script.
- Workflows 03-04 calculate the median using all expression-matrix samples before
  merging clinical data. Workflow 05 calculates it after matching clinical samples
  and excluding `dlco == 0`. The Wilcoxon rank-sum calls use `exact = FALSE` and
  `correct = FALSE`. Scatter plots report Spearman correlations; the displayed
  regression line and confidence band come from a linear model.
- Workflows 06-07 intersect each cohort with the specified gene set. For each gene,
  `scale()` standardizes expression across that cohort's samples; genes with zero
  standard deviation contribute zero. The sample score is the mean of those
  gene-level Z-scores. At least two score genes are required. Spearman correlations
  order the combined panels from the highest to the lowest rho. The tests are
  unadjusted; no multiple-testing correction was active in the source.

## Recorded analysis limitations

**Legacy event recoding in workflow 02:** when `surTime > 1000`, the source changes
`surStatus` to `0` while keeping the recorded follow-up time. The release preserves
this operation and exposes `legacy_event_threshold <- 1000`. This operation is an
event-status recoding; methodological confirmation is needed before treating the
curve as an administrative censoring analysis at 1000 days.

The disease filters in workflows 02-04 were inactive in the source. These scripts
retain all input clinical groups and must not be described as IPF-only analyses
without checking the supplied sample metadata.

The active gene list in workflow 06 exactly matched 159 genes in
`KEGG_PURINE_METABOLISM.v2026.1.Hs.tsv`. Its old label, "Adenylation Score", was
replaced with "Purine metabolism score (Mean Z-score)". Workflow 07 uses 54 genes
from `HALLMARK_TGF_BETA_SIGNALING.v2026.1.Hs.txt`; its score labels now identify
TGF-beta signaling. These are expression-based scores.

Earlier ENTPD1/TGF-beta correlation figures were present in the source folder, but
their generation version was absent from the saved R scripts. Workflow 07 preserves
the saved ADORA2B analysis and does not stand in for that missing ENTPD1 version.

## Packaging changes and environment

The 14 source R files contained 8 byte-unique versions and 7 analysis workflows.
Six root/nested pairs were byte-identical. The two TGF-beta versions shared the
analysis body and differed in preparatory file operations; both map to workflow 07.
The release keeps the analysis body and excludes the preparatory file operations.
The detailed hash-to-workflow mapping is recorded in the repository provenance docs.

Changes include English sequential file names, configurable relative paths,
independent output directories, input checks, removal of automatic package
installation and workspace-clearing commands, and removal of duplicate plotting
passes. Pulmonary-function boxplot labels identify the measured endpoint. Jitter
uses a fixed seed (`1`) to make point placement repeatable. Statistical formulas and
the active cohort/group filters remain as described above.

Install `survival`, `survminer`, `ggplot2`, `ggpubr`, and `cowplot` before running
the relevant workflow. The source loaded `dplyr` and `RColorBrewer` in some scripts;
the cleaned scripts use equivalent base-R data operations and do not require them.
Exact historical package versions were not recorded. Existing source PDFs identify
R 4.5.1 as their export producer. `session_info.txt` records the environment for each
new run; it does not reconstruct the historical environment.
