# Shared paths and input checks. Run Rscript commands from the repository root.
# Data and result locations may be configured with environment variables.
REPO_ROOT <- getwd()
if (!file.exists(file.path(REPO_ROOT, "R", "_paths.R"))) {
  stop("Run this workflow from the repository root: Rscript R/<workflow>.R")
}
DATA_DIR <- Sys.getenv("SRSF1_DATA_DIR", unset = file.path(REPO_ROOT, "data"))
RESULTS_DIR <- Sys.getenv("SRSF1_RESULTS_DIR", unset = file.path(REPO_ROOT, "results"))
RESOURCE_DIR <- file.path(REPO_ROOT, "resources")

require_inputs <- function(paths) {
  missing <- paths[!file.exists(paths)]
  if (length(missing)) {
    stop("Required input files are missing:\n", paste(missing, collapse = "\n"),
         "\nSee R/README.md for file formats; configure SRSF1_DATA_DIR if needed.")
  }
}

require_columns <- function(data, columns, label) {
  missing <- setdiff(columns, colnames(data))
  if (length(missing)) {
    stop(label, " is missing columns: ", paste(missing, collapse = ", "))
  }
}

require_numeric <- function(data, columns, label) {
  invalid <- columns[!vapply(data[, columns, drop = FALSE], is.numeric, logical(1))]
  if (length(invalid)) {
    stop(label, " requires numeric columns: ", paste(invalid, collapse = ", "))
  }
}

require_gene <- function(expression, gene) {
  if (!gene %in% rownames(expression)) stop("Expression matrix is missing gene: ", gene)
  if (!all(vapply(expression, is.numeric, logical(1)))) {
    stop("Expression matrix sample columns must all be numeric.")
  }
}

require_packages <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    stop("Install required packages before running: ", paste(missing, collapse = ", "))
  }
  invisible(lapply(packages, library, character.only = TRUE))
}

workflow_results <- function(name) {
  output_dir <- file.path(RESULTS_DIR, name)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  output_dir
}

record_session <- function(output_dir) {
  writeLines(capture.output(sessionInfo()), file.path(output_dir, "session_info.txt"))
}

read_msigdb_symbols <- function(path) {
  require_inputs(path)
  # The recorded Hallmark export uses UTF-16LE; the KEGG export uses UTF-8.
  signature <- readBin(path, what = "raw", n = 2)
  if (identical(signature, as.raw(c(255, 254)))) {
    # Decode the original ASCII gene-set metadata without relying on host locale.
    bytes <- as.integer(readBin(path, what = "raw", n = file.info(path)$size))
    codepoints <- bytes[seq.int(3, length(bytes), 2)] +
      256 * bytes[seq.int(4, length(bytes), 2)]
    lines <- strsplit(intToUtf8(codepoints), "\n", fixed = TRUE)[[1]]
    lines <- sub("\r$", "", lines)
  } else {
    lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  }
  symbols_line <- lines[startsWith(lines, "GENE_SYMBOLS\t")]
  if (length(symbols_line) != 1) {
    stop("Gene-set metadata must contain one tab-separated GENE_SYMBOLS row: ", path)
  }
  symbols <- sub("^[^\t]*\t", "", symbols_line)
  symbols <- gsub('^"|"$', "", symbols)
  strsplit(symbols, ",", fixed = TRUE)[[1]]
}
