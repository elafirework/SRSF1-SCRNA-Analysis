# Source notebooks

These notebooks retain the four distinct supplied analysis versions. The identical second copy of the bulk notebook is represented once. Notebook numbers organize the repository; they do not imply that the notebooks form one sequential pipeline.

| Order | Notebook | Original code cells | Role |
| --- | --- | ---: | --- |
| 01 | [Bulk seven-gene ssGSEA](01_bulk_seven_gene_ssgsea_exploratory.ipynb) | 3 | Historical exploratory attempt; recorded cohort analyses failed gene-set filtering. |
| 02 | [GSE136831 main](02_single_cell_gse136831.ipynb) | 123 | Main source version, including the later expression violin plots and statistics. |
| 03 | [GSE136831 legacy](03_single_cell_gse136831_legacy_106cells.ipynb) | 106 | Earlier source version retained for comparison. |
| 04 | [GSE136831 historical Linux](04_single_cell_gse136831_linux_87cells.ipynb) | 87 | Distinct historical Linux source version. |

## Setup and paths

Install the Python dependencies from the root [requirements.txt](../requirements.txt) before opening a notebook. Start Jupyter from the repository root. The first code cell imports `DATA_DIR` and `RESULTS_DIR` from `repo_config.py`, supporting a kernel whose working directory is either the repository root or `notebooks/`.

The shared configuration reads `SRSF1_DATA_DIR` and `SRSF1_RESULTS_DIR`. Their defaults are the repository's `data/` and `results/` directories. Supply these logical inputs under `DATA_DIR`:

```text
data/
  bulk_expression/
    GSE.../
      GSE..._matrix.txt
  single_cell/
    processed_GSE136831.h5ad
    GSE136831_AfterUmap.h5ad
    GSE136831_Fib_umap_02.h5ad
```

Bulk matrices require gene rows and sample columns. The original bulk input directory and the initial `processed_GSE136831.h5ad` object were absent from the supplied project. The two later single-cell checkpoint objects were present locally, and their data are not embedded in this code repository. See the repository data documentation for input availability.

All explicit exports go to `RESULTS_DIR/<notebook_stem>/`; Scanpy exports go to its `figures/` subdirectory. Generated checkpoint objects also go to the results directory. Checkpoint reads continue to use the documented inputs under `DATA_DIR`, so a generated result does not silently replace a supplied input.

## Source cell numbering and navigation

Each notebook has one added Markdown guide at the beginning. Original source cell **N** is release cell **N+1**, with stable ID `source-cell-NNN`. Cell numbers below always refer to the original source numbering. [cell_provenance.csv](cell_provenance.csv) records both positions, the original and cleaned source hashes, and the change description for each cell.

For the main notebook:

| Source cells | Analysis content |
| --- | --- |
| 1 | Dependencies and shared repository path setup. |
| 2-23 | Load the initial processed object; whole-cell processing, UMAP, and checkpoint export. |
| 24-42 | Load the supplied whole-cell UMAP checkpoint and inspect annotated cells. Cell 29 reloads the object and removes the recorded proliferating-EC subset. |
| 43-53 | Later SRSF1 expression violin plots and cell-level IPF/CON statistics. |
| 54-82 | Exploratory expression plots, cell-type subsets, and matrix/UMAP figures. |
| 83-96 | Fibroblast preprocessing, Harmony, clustering, and checkpoint export. |
| 97-110 | Load the supplied fibroblast checkpoint; clustering plots and marker-gene analyses. |
| 111-123 | Scanpy purine-metabolism `score_genes`, cell-level comparisons, expression matrixplots, and score UMAP. |

Run the setup cell before selecting a checkpoint branch. The supplied source combines exploration, checkpoint reloads, and different object states; its original cell order is preserved for auditability. A figure-specific execution sequence requires the corresponding checkpoint, object state, and parameters. Static validation does not establish complete top-to-bottom scientific reproduction.

The legacy and Linux versions retain their own cell numbering. Their per-cell source hashes can be compared with the main version in `cell_provenance.csv`.

## Changes made for sharing

- Replaced machine-specific absolute paths with the shared data/results configuration.
- Translated Chinese comments and console messages into English; standardized the output filename `03_purine_metabolism_score.pdf`.
- Removed all saved outputs, execution counts, and cell execution metadata. Retained generic Python kernel metadata and the original recorded Python version.
- Converted inline `pip` installation and IPython display commands to comments. Removed active `scvi_colab` installation and disabled unused optional scVI/Torch setup from the historical Linux environment. The supplied notebooks contain no scVI model training.
- Preserved every original code cell with a stable source ID. Explicitly disabled the historical cells listed below, retaining their cleaned source as comments.

| Version | Source cells disabled | Reason |
| --- | --- | --- |
| Main | 33 | Replaced the AnnData object with a Boolean Series. |
| Main | 35 | Recorded `AttributeError` after the invalid object assignment. |
| Main | 66 | Recorded `NameError` in a display-only cell. |
| Main | 116 | Recorded `KeyError` from the wrong object; its historical filename incorrectly called `score_genes` AUCell. |
| Legacy | 49 | Recorded `NameError` in a display-only cell. |
| Legacy | 99 | Same invalid score-violin call and AUCell filename. |
| Linux | 85 | Same invalid score-violin call and AUCell filename. |

Analysis formulas, gene lists, score parameters, comparison groups, and plotting thresholds remain those of the supplied source. Corrected comments identify the retained uppercase human gene list and the actual `score_genes` method; these wording changes do not replace the source algorithms.

## Interpretation and reproducibility notes

The GSE136831 source begins with a processed AnnData object. Raw-count preprocessing, cell annotation, and upstream scVI training scripts were not supplied. The notebooks contain repeated normalization and object reloads, and the historical Harmony log stopped before convergence. Determine the object state used for the target figure before rerunning those stages.

The later positive-expression violin comparisons use cell-level observations, with the recorded filtering and Mann-Whitney/BH procedure. They do not aggregate observations by donor. The three-group pathway comparison also uses cell-level observations and has no explicit multiple-comparison correction in the supplied code.

Several source cells save to the same filename within a notebook. In the main version, cells 44/53 share one nonzero-expression violin filename; cells 46/51/52 share IPF/CON violin filenames; cells 81/82 share a custom UMAP filename. Each notebook has a separate output directory, while these original within-notebook overwrite relationships are retained. Use the per-cell mapping to select the intended version of a figure.

The bulk notebook retains its original seven-gene ssGSEA call, including the unspecified `min_size`; the recorded run failed filtering. It is an exploratory source record, distinct from the R mean-Z-score analyses that produced the existing bulk correlation figures.

## Validation and provenance files

- [notebook_source_manifest.json](notebook_source_manifest.json): all five supplied notebook files represented by English aliases, original whole-file hashes, cleaned-file hashes, duplicate status, recorded Python versions, and disabled-cell lists.
- [cell_provenance.csv](cell_provenance.csv): all 322 original cells, including the exact duplicate bulk copy, mapped to cleaned release cells and source hashes.
- [validation_report.json](validation_report.json): notebook-schema validation and Python AST/compile checks. These checks do not execute the analyses or read the scientific data.

Original notebook files remain in the source project and were not modified.
