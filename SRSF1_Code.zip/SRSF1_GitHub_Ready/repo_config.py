"""Shared, portable paths for the SRSF1 analysis repository."""

import os
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent


def _configured_path(variable: str, default: Path) -> Path:
    value = os.environ.get(variable)
    path = Path(value).expanduser() if value else default
    if not path.is_absolute():
        path = REPO_ROOT / path
    return path.resolve()


DATA_DIR = _configured_path("SRSF1_DATA_DIR", REPO_ROOT / "data")
RESULTS_DIR = _configured_path("SRSF1_RESULTS_DIR", REPO_ROOT / "results")


def require_input(path: Path) -> Path:
    """Return an existing input path or raise an actionable error."""
    if not path.is_file():
        raise FileNotFoundError(
            f"Required input file not found: {path}\n"
            "See data/README.md and docs/data_accessions.csv for input setup."
        )
    return path


def prepare_results() -> Path:
    """Create the configured results directory when an analysis is run."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    return RESULTS_DIR
