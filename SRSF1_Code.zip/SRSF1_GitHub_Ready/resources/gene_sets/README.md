# Gene-set inputs

The bulk R workflows read the following MSigDB gene-set metadata files from this
directory. Obtain these resources through MSigDB and place them here before running
workflows 06-07. Third-party gene-set files are external inputs to the code release.

| Required file | Gene-set page | Recorded definition | Source-file SHA-256 |
| --- | --- | --- | --- |
| `KEGG_PURINE_METABOLISM.v2026.1.Hs.tsv` | [KEGG_PURINE_METABOLISM](https://www.gsea-msigdb.org/gsea/msigdb/human/geneset/KEGG_PURINE_METABOLISM) | MSigDB filename version `v2026.1.Hs`; C2:CP:KEGG_LEGACY, hsa00230; 159 symbols | `ea4147deba5e68e2f9cf40b70c92a8c81990553aab12800a6cfc85c7539df900` |
| `HALLMARK_TGF_BETA_SIGNALING.v2026.1.Hs.txt` | [HALLMARK_TGF_BETA_SIGNALING](https://www.gsea-msigdb.org/gsea/msigdb/human/geneset/HALLMARK_TGF_BETA_SIGNALING) | MSigDB filename version `v2026.1.Hs`; Hallmark collection; 54 symbols | `7651434a076e289c38f809099ca23d3b13b953a120579f2ecb12240a6e3aac45` |

1. Open the gene-set page and sign in to MSigDB if requested.
2. Retrieve the human gene-set metadata for the recorded release. Preserve the
   tab-separated metadata export, including the `GENE_SYMBOLS` row. If the web page
   now serves a later release, use the recorded release/archive or the original
   local resource retained by the study authors.
3. Save the metadata under the exact file name above. The scripts parse the
   comma-separated symbols from `GENE_SYMBOLS`; a GMT file has a different layout.
4. Compare the file checksum with the source checksum to verify an identical copy.
   A different checksum may reflect changed metadata or gene membership; compare
   the release and complete symbol list before interpreting the score as the
   original definition.

The recorded gene counts and symbol order exactly matched the active vectors in
the original analysis scripts. The release reads these definitions as data rather
than duplicating them inside R code. Access and use follow the terms displayed by
MSigDB and the underlying resource providers.
