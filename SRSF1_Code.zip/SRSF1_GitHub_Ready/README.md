# SRSF1 bioinformatics analyses

Portable analysis code for the SRSF1/IPF study. This repository separates the preserved R and Python workflows, makes input and output paths configurable, and documents which saved figures have a traceable source script or notebook cell.

## Repository status

This is a cleaned source-code snapshot prepared from the analysis folder on 2026-11-26. It has not been used to recompute the manuscript results. Several historical figure-generation scripts and required processed inputs were not present in the source folder. The figure-to-code table identifies these gaps rather than assigning a different analysis script to the figure.

The accession list and original source audit are documented in `docs/`. Raw or derived research data are not included. No public repository, DOI, or software license has been assigned yet.

## Contents

- `R/`: portable R analysis scripts in workflow order.
- `notebooks/`: cleaned, output-stripped Jupyter notebooks. The notebooks are preserved as distinct historical versions where their source differs.
- `repo_config.py`: Python input/output path configuration.
- `data/`: local inputs; ignored by Git.
- `resources/gene_sets/`: setup instructions for third-party gene sets.
- `results/`: generated outputs; ignored by Git.
- `docs/data_accessions.csv`: datasets and known input requirements.
- `docs/figure_code_map.csv`: visual asset to source-code mapping. F identifiers are audit identifiers, not final manuscript figure numbers.
- `docs/software_versions.md`: software versions evidenced by saved analysis artifacts and notebooks.
- `LICENSE_STATUS.md`: license selection remains an author decision.

## Requirements

R workflows use the packages declared at the top of each script and summarized in `R/README.md`. Python workflows use the packages in `requirements.txt`. The historical notebooks recorded different Python environments, so the requirements file is a starting point for a new environment, not a claim that every historical figure was generated in one locked environment.

Install the Python dependencies in a dedicated environment, then open the notebooks:

```bash
python -m venv .venv
# Activate .venv using the command for your operating system.
python -m pip install -r requirements.txt
jupyter lab
```

To configure data outside this repository, set `SRSF1_DATA_DIR`. To redirect generated figures and tables, set `SRSF1_RESULTS_DIR`. Without these variables, the workflows use the ignored `data/` and `results/` directories in this repository.

Example in PowerShell:

```powershell
$env:SRSF1_DATA_DIR = "../SRSF1_data"
$env:SRSF1_RESULTS_DIR = "../SRSF1_results"
```

Example in Bash:

```bash
export SRSF1_DATA_DIR=../SRSF1_data
export SRSF1_RESULTS_DIR=../SRSF1_results
```

## Workflow

Run R analyses from the repository root using the order and input table in `R/README.md`. Launch Jupyter from the repository root so `repo_config.py` can resolve paths. The bulk seven-gene ssGSEA notebook is an exploratory historical attempt; its recorded run did not produce successful cohort correlation figures. The single-cell notebook starts from processed AnnData objects and does not reproduce the upstream raw-count quality control, cell annotation, or model training.

Check `data/README.md` before running. R entry points check their required input files; notebook inputs use the shared directory configuration. Some cleaned clinical and expression inputs, bulk matrices, and the upstream processed single-cell entry object need to be recovered or independently reconstructed and documented.

## Validation

Run the repository structure checks from the root directory:

```bash
python scripts/validate_repo.py
python -m unittest discover -s tests -v
```

These checks validate source structure, Python syntax, notebook output removal, portable paths, and path configuration. R syntax can be checked separately with:

```bash
Rscript --vanilla -e 'for (f in list.files("R", pattern="[.]R$", full.names=TRUE)) parse(f)'
```

Full result validation requires the original inputs and documented software environment. See `docs/validation.md` for the checks performed on this snapshot.

## Availability and citation

Before release, add the selected software license and the repository URL or archived release DOI to the manuscript's Code availability statement. Cite each public dataset by accession as listed in `docs/data_accessions.csv`. Replace this section with the final repository citation after the authors select the release location.
