# Input data

This repository does not include raw or processed patient-level or single-cell datasets. Keep downloaded data under this directory or set `SRSF1_DATA_DIR` to a separate local data directory. The repository ignores the contents of `data/` by default.

Use the accession and required-file table in [`../docs/data_accessions.csv`](../docs/data_accessions.csv) to retrieve public GEO series. The analysis scripts expect the documented processed matrices and sample metadata. Public access to a GEO accession does not imply that every locally derived file used by the historical analysis is deposited there.

The required processed AnnData files and cleaned lung-function tables are not supplied. Their source, preprocessing, and access conditions must be verified before claiming that the workflows can be reproduced from public downloads alone. Do not commit controlled-access or identifiable data.
