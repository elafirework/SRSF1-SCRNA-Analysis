"""Check the source-only repository without loading research data or packages."""

import ast
import csv
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ABSOLUTE_PATH = re.compile(r"\b[A-Za-z]:[\\/]|/(?:home|storage|Users|mnt)/|\\\\[A-Za-z0-9_.-]+\\")
DESTRUCTIVE = re.compile(r"shutil\.rmtree\s*\(|\bos\.remove\s*\(|\bunlink\s*\(|Remove-Item\b")
INSTALL = re.compile(r"\binstall\.packages\s*\(|\bBiocManager::install\s*\(|^[ \t]*[!%].*\bpip\s+install\b", re.M)
SOURCE_SUFFIXES = {".py", ".r", ".ipynb"}


def notebook_code(source):
    """Translate IPython-only lines to pass for a Python syntax check."""
    return "\n".join(
        "pass" if line.lstrip().startswith(("%", "!")) else line
        for line in source.splitlines()
    )


def string_values(value):
    """Read decoded JSON strings so escaped newlines are not mistaken for paths."""
    if isinstance(value, str):
        yield value
    elif isinstance(value, list):
        for item in value:
            yield from string_values(item)
    elif isinstance(value, dict):
        for item in value.values():
            yield from string_values(item)


def validate():
    errors = []
    files = [p for p in ROOT.rglob("*") if p.is_file() and not any(
        part in {".git", "__pycache__", ".ipynb_checkpoints", ".venv"}
        for part in p.relative_to(ROOT).parts
    )]
    notebooks = 0
    code_files = 0
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        if not relative.isascii():
            errors.append(f"Non-ASCII filename: {relative}")
        if path.stat().st_size > 10 * 1024 * 1024:
            errors.append(f"Large file included in code repository: {relative}")
        if path.suffix.lower() not in SOURCE_SUFFIXES:
            continue
        code_files += 1
        text = path.read_text(encoding="utf-8-sig")
        scan_text = text
        if path.suffix == ".ipynb":
            try:
                scan_text = "\n".join(string_values(json.loads(text)))
            except ValueError:
                pass  # The notebook validation below reports malformed JSON.
        # The validator contains examples of the patterns it detects.
        if path != Path(__file__).resolve():
            for label, pattern in [("Absolute machine path", ABSOLUTE_PATH),
                                   ("File deletion operation", DESTRUCTIVE),
                                   ("Automatic package installation", INSTALL)]:
                match = pattern.search(scan_text)
                if match:
                    errors.append(f"{label}: {relative}")
        if path.suffix == ".py":
            try:
                ast.parse(text, filename=relative)
            except SyntaxError as error:
                errors.append(f"Python syntax: {relative}: {error}")
        elif path.suffix == ".ipynb":
            notebooks += 1
            try:
                notebook = json.loads(text)
                assert notebook.get("nbformat") == 4, "expected nbformat 4"
                assert isinstance(notebook.get("cells"), list), "cells must be a list"
                for index, cell in enumerate(notebook["cells"], 1):
                    if cell.get("cell_type") != "code":
                        continue
                    assert cell.get("outputs") == [], f"cell {index} retains outputs"
                    assert cell.get("execution_count") is None, f"cell {index} retains execution count"
                    source = cell.get("source", [])
                    source = "".join(source) if isinstance(source, list) else source
                    ast.parse(notebook_code(source), filename=f"{relative}:cell {index}")
            except (ValueError, AssertionError, SyntaxError) as error:
                errors.append(f"Notebook validation: {relative}: {error}")
    if errors:
        print("Repository validation failed:")
        print("\n".join(f"- {error}" for error in errors))
        return 1
    manifest = ROOT / "notebooks" / "notebook_source_manifest.json"
    if manifest.is_file():
        for item in json.loads(manifest.read_text(encoding="utf-8-sig")):
            release = ROOT / item["release_file"]
            if not release.is_file():
                errors.append(f"Missing notebook source: {item['release_file']}")
            elif hashlib.sha256(release.read_bytes()).hexdigest() != item["release_file_sha256"]:
                errors.append(f"Notebook checksum mismatch: {item['release_file']}")
    coverage = ROOT / "docs" / "source_code_coverage.csv"
    if coverage.is_file():
        with coverage.open(encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                if not (ROOT / row["release_file"]).is_file():
                    errors.append(f"Missing release destination: {row['release_file']}")
    if errors:
        print("Repository provenance validation failed:")
        print("\n".join(f"- {error}" for error in errors))
        return 1
    print(f"PASS: {len(files)} files, {code_files} source files, {notebooks} cleared notebooks.")
    print("Research inputs and scientific results were not executed by this check.")
    return 0


if __name__ == "__main__":
    sys.exit(validate())
