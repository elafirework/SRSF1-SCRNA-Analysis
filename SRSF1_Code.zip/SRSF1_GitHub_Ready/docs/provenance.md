# Source and data provenance

This release was prepared on 2026-11-26 from the supplied SRSF1/IPF analysis folder. It organizes and sanitizes source code for sharing. Release preparation did not recompute the manuscript results.

## Source coverage

The original folder contained 14 expanded R files and five expanded notebooks. Byte-identical copies reduce these to eight R versions and four notebook versions. Nine R/notebook members in the original analysis archive duplicate these expanded versions. The 12 original source versions map to 11 released workflows: seven R scripts and four notebooks. The two ADORA2B R versions share the analysis and are consolidated after removing their different preparatory filesystem-edit blocks. `source_code_coverage.csv` records every source hash and release destination without exposing machine paths or original localized filenames.

English sequential filenames describe the analysis actually present in each source. Two historical survival filenames used dataset or gene names that differed from their code. Released names follow ENTPD1/GSE28221 and ENTPD1/GSE70866. The bulk TGF-beta scripts analyze ADORA2B, despite the historical gene name in their filenames. Both original ADORA2B hashes map to the released ADORA2B workflow.

Original notebook outputs, execution counts and environment-specific display metadata are removed. Notebook source-cell identities and cleaning changes are recorded in `../notebooks/cell_provenance.csv`. Original source hashes identify pre-cleaning files; cleaned files have different hashes. The private original-to-release path mapping is retained outside this repository.

## Data access

`data_accessions.csv` records accessions, canonical landing pages, local evidence and required processed inputs. Landing pages were not checked online during this preparation. An accession entry documents local evidence and does not establish that every locally derived matrix is deposited at that accession.

The single-cell notebooks start from processed GSE136831 AnnData objects. Three processed objects were present: an all-cell object with 237434 cells, a fibroblast object with 5515 cells, and a later fibroblast object with 5262 cells. The initial processed input object, upstream raw-count workflow, inherited annotations and earlier model training are absent from the supplied source. Fields named after an algorithm do not establish that the supplied notebooks ran that algorithm upstream.

The local GSE32537 series matrix identifies GPL6244 and describes log2-transformed, RMA-quantile-normalized expression across 217 samples. The extracted lung-function table contains GEO sample identifiers, St George total score, FVC percent predicted and DLCO percent predicted. The gene-symbol matrix expected by the R analysis lacks its conversion script.

Bulk analyses require locally prepared gene-level matrices and, for clinical analyses, sample metadata. The historical bulk notebook stored listings for 25 GEO/platform cohort folders and a separate local cohort named liang. Those processed input folders are absent. No public accession was identified for the local cohort.

MTBLS13445 metadata concern rodent spatial metabolomics, with bleomycin-treated mouse and AZX-treated rat samples. They do not establish provenance for the separate ST004033/AN006670 feature matrix or the saline-versus-bleomycin differential table. These resources are listed separately with their evidence status.

## Figure traceability

`figure_code_map.csv` covers 83 distinct historical assets. F identifiers are audit identifiers, not manuscript figure numbers. Asset hashes identify the original saved files, which are not bundled. English aliases identify presentation and supplementary-archive assets whose original names were localized.

Evidence grade A means direct source/output evidence. B means a related source or parameter family with incomplete identity. C means the generating source is absent or unverified. A source match is not a successful rerun. Historical source cell numbers are one-based; release notebook cell numbers add one introductory cell. Historical R line ranges are provenance references, because formatting and configuration edits shift release line numbers.

Specific gaps in the historical assets are:

- The ENTPD1 bulk combined correlation figures and most individual ENTPD1/TGF-beta plots lack the matching generating version. Current ADORA2B code must not be assigned to those figures.
- The composite figure contains labeled panels without matching generating code, including GSE83717/GSE110147 expression panels and an unresolved panel h. Experimental panels are outside the computational source supplied.
- Several violin filenames disagree with the cell-type field used in code. Different cells overwrite the same output filename. Asset hashes and cell-specific filtering distinguish versions.
- The four-class IPF/CON violin figures have no explicit matching save call. Supplementary-archive violin versions have no uniquely established generating cell.
- The Omicverse proportion plot has a related plotting call without an explicit matching save statement.

## Preserved analytical limits

The exploratory seven-gene bulk ssGSEA notebook retained failed historical runs. It does not establish successful generation of the saved bulk figures. Scanpy `score_genes`, mean gene-wise Z scores and ssGSEA are distinct procedures and retain their actual names in the documentation.

Single-cell group comparisons treat cells as observations. The supplied code does not implement donor-level aggregation or mixed models. Some expression comparisons retain positive cells only; the source cells and figure mapping record that selection. These results describe the selected cells rather than an established donor-level disease contrast.

The GSE70866 survival workflow retains the original event recoding for follow-up above 1000. This rule and survival time units require source verification before reuse. GSE47460 workflows retain the original commented disease filter, so the original analysis population requires confirmation.

## Excluded files and release status

The release contains source code, configuration and documentation. Large AnnData objects, downloaded matrices, clinical data, metabolomics tables, composite artwork, presentations, duplicate archives and prior audit reports are excluded. No raw sequencing or MS imaging files were found among the local inputs inspected.

Processed single-cell metadata contain public sample identifiers together with age, sex, smoking, ethnicity, disease and sample annotations. The code repository excludes those object-level records. Third-party database references and gene sets retain their source attribution; a project software license does not relicense third-party data.

A public repository URL, archival DOI, software license and locked historical environment remain release metadata for the authors to supply. Scientific result reproducibility requires the missing processed inputs and upstream provenance to be resolved.
