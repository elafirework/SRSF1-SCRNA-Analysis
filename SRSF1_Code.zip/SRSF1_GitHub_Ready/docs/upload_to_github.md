# Upload this repository

The repository is prepared locally. Select the GitHub account, repository name, visibility, and software license before publishing. `LICENSE_STATUS.md` records the current license status.

## Upload through the GitHub website

1. Create an empty repository in your GitHub account with the intended visibility.
2. Extract the delivered ZIP archive locally.
3. Open the new repository, choose **Add file > Upload files**, and upload the contents of the extracted directory. Include `.gitignore` and `.gitattributes`.
4. Check that `README.md`, `R/`, `notebooks/`, `docs/`, and the dependency files appear at the repository root. Commit the upload.

The ZIP contains the source repository and documentation. Keep local data, generated outputs, and the private filename crosswalk outside the upload.

## Upload with Git

From the prepared repository directory, run:

```bash
git status
git add .
git commit -m "Prepare bioinformatics analysis source"
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with the HTTPS or SSH URL displayed by GitHub. Git may request your configured author identity and account authentication. Review the staged file list before committing.

After publication, add the verified URL to the manuscript Code availability statement. A tagged release can subsequently be archived with a persistent DOI. Record the actual release identifier after it is assigned.
