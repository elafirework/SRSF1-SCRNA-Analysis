# Validation of the sharing snapshot

Validation date: 2026-11-26.

| Check | Result |
| --- | --- |
| Source coverage | All 19 original expanded code files and nine archived code members map to the release. Twelve distinct original versions map to seven R analyses and four notebooks. |
| Original source integrity | SHA-256 checks of all 19 expanded original code files match the pre-cleaning inventory. |
| Naming | Release filenames and directory names use ASCII English names; analysis files use numerical prefixes. |
| Portable source | Source scan passes for local absolute paths, file-deletion operations and automatic package installation. |
| Notebook cleanup | All four notebooks have empty outputs and null execution counts. |
| Notebook syntax | Notebook schema, active Python AST parsing and compilation pass. |
| R syntax | All seven analysis scripts and the shared helper parse with R 4.5.1. |
| R missing-input behavior | Each of the seven entry points stops with the expected missing-input message before loading research data. |
| Shared configuration | Three Python tests pass for default/relative/absolute paths, output creation and missing input handling. R defaults and the input-directory override were also checked. |
| Provenance links | All source destinations exist; notebook file hashes and figure-to-notebook cell positions were checked. |

These checks validate source preparation. The scientific analyses were not rerun, and numerical agreement with historical figures was not established. Required processed matrices, upstream single-cell preprocessing and some generating source versions remain absent, as recorded in `provenance.md` and `data_accessions.csv`.

Python checks used Python 3.12. Historical environment evidence is recorded separately in `software_versions.md`. No historical package lockfile was reconstructed from mixed installation logs.

To repeat the source checks, run the commands in the root README. The original-name crosswalk and integrity report are retained in the private preparation directory outside the public repository.
