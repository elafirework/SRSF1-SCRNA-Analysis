# Software version evidence

The versions below come from historical notebook metadata, stored installation logs and saved PDF metadata. They describe separate recorded sessions and do not constitute a single locked environment. Current local software versions were not substituted for the historical evidence.

| Component | Recorded version | Evidence |
|---|---|---|
| R | 4.5.1 | Producer metadata of saved R PDF figures |
| R packages | Not recorded | No original sessionInfo or package lockfile found |
| Python, bulk exploratory notebook | 3.10.4 | Original notebook language metadata |
| Python, main single-cell notebook | 3.10.15 | Original notebook language metadata |
| Python, legacy 106-cell notebook | 3.10.4 | Original notebook language metadata |
| Python, Linux 87-cell notebook | 3.10.19 | Original notebook language metadata |
| Scanpy | 1.11.4 | Main single-cell notebook, historical source cell 102 installation output |
| AnnData | 0.11.4 | Main single-cell notebook, historical source cell 102 |
| NumPy | Windows 2.2.6; Linux 1.24.4 | Stored installation outputs from different sessions |
| pandas | Windows 2.3.2; Linux 2.3.3 | Stored installation outputs from different sessions |
| SciPy | Windows 1.15.3; Linux 1.11.4 | Stored installation outputs from different sessions |
| Matplotlib | Windows 3.10.6; Linux 3.10.8 | Stored installation outputs from different sessions |
| seaborn | 0.13.2 | Stored installation outputs |
| statsmodels | 0.14.5 | Main single-cell notebook, historical source cell 102 |
| python-igraph | 0.11.9 | Main single-cell notebook, historical source cell 102 |
| numba | 0.61.2 | Main single-cell notebook, historical source cell 102 |
| Omicverse | 2.1.2 | Main single-cell notebook, historical source cells 102 and 104 |
| statannotations | 0.7.2 | Main source cell 112 and Linux source cell 81 installation output |
| GSEApy | 1.2.1 | Bulk source cell 2; recorded analysis attempt failed |
| harmonypy | Not recorded | Calls and iteration logs present; package version absent |
| leidenalg | Not recorded | Package version absent; fibroblast clustering specifies igraph in source |
| scvi-tools / torch | No analysis version established | Inherited object fields do not establish model training in the supplied notebooks |

Historical source cell numbers are one-based. Cleaned notebooks add one introductory Markdown cell, so the corresponding release cell is the historical cell plus one. See `../notebooks/cell_provenance.csv` for the exact mapping.

`../requirements.txt` lists baseline Python dependencies. It is not an environment lockfile. R dependencies are listed in `../R/README.md`. Recomputing results requires the correct inputs and a documented environment.
