# License status

No software license has been selected for this repository. GitHub hosting does not by itself grant permission to reuse or redistribute the code. Before publishing, the authors should choose a license consistent with institutional, journal, and third-party requirements and add the corresponding full license text.
